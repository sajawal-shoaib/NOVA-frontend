import { useEffect, useRef, useState } from "react"
import { AnimatePresence, motion } from "framer-motion"
import { Link, useNavigate } from "react-router-dom"
import { Search, X, Sparkles, Loader2 } from "lucide-react"
import { useStore } from "../context/StoreContext"
import { formatPrice } from "../lib/format"

export default function SearchOverlay() {
  const { searchOpen, setSearchOpen, searchProducts, products = [] } = useStore()
  const [query, setQuery] = useState("")
  const [results, setResults] = useState([])
  const [aiIntent, setAiIntent] = useState(null)
  const [loading, setLoading] = useState(false)
  const inputRef = useRef(null)
  const navigate = useNavigate()

  useEffect(() => {
    if (searchOpen) {
      const t = window.setTimeout(() => inputRef.current?.focus(), 150)
      return () => window.clearTimeout(t)
    }
    setQuery("")
    setResults([])
    setAiIntent(null)
  }, [searchOpen])

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") setSearchOpen(false)
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [setSearchOpen])

  // AI Smart Search + Fallback Logic
  useEffect(() => {
    const cleanQuery = query.trim()
    if (!cleanQuery) {
      setResults([])
      setAiIntent(null)
      setLoading(false)
      return
    }

    // Immediate fallback search using local function
    const localResults = searchProducts ? searchProducts(cleanQuery) : []
    setResults(localResults.slice(0, 10))

    const timer = setTimeout(async () => {
      setLoading(true)
      try {
        const res = await fetch("http://localhost:5000/api/ai/parse-search", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ query: cleanQuery }),
        })

        if (!res.ok) throw new Error(`HTTP Error: ${res.status}`)

        const intent = await res.json()

        // 1. Convert price to a clean number
        const maxPrice = intent.maxPrice ? Number(intent.maxPrice) : null

        // 2. Clean keywords and handle broad words like "cloths" / "clothes"
        let cleanKeywords = (intent.keywords || [])
          .map((k) => k.toLowerCase())
          .filter(
            (word) =>
              !/^\d+$/.test(word) &&
              !["under", "below", "less", "cheap", "than", "dollar", "dollars"].includes(word)
          )

        // Broad terms list for clothing
        const clothingSynonyms = ["cloth", "cloths", "clothes", "clothing", "apparel", "wear", "outfit"]
        const isClothingQuery = clothingSynonyms.some((term) =>
          cleanQuery.toLowerCase().includes(term) || cleanKeywords.includes(term)
        )

        if (isClothingQuery) {
          cleanKeywords = [
            ...cleanKeywords,
            ...clothingSynonyms,
            "shirt",
            "pant",
            "jacket",
            "hoodie",
            "top",
            "knit",
            "set",
            "dress",
          ]
        }

        const cleanCategory = intent.category ? intent.category.toLowerCase() : null

        setAiIntent({
          ...intent,
          maxPrice,
          keywords: cleanKeywords,
          category: cleanCategory,
        })

        const allItems = products.length > 0 ? products : localResults

        // Filter products using parsed AI intent
        const aiMatched = allItems.filter((product) => {
          const productPrice = Number(product.price)

          // Price constraint
          if (maxPrice && !isNaN(maxPrice) && productPrice > maxPrice) {
            return false
          }

          // Combine product text fields
          const productText = `${product.name || product.title || ""} ${
            product.description || ""
          } ${product.category || ""} ${product.slug || ""}`.toLowerCase()

          // Pure price query check
          if (cleanKeywords.length === 0 && !cleanCategory) {
            return true
          }

          // Synonym & Category Matching
          const matchesKeyword = cleanKeywords.some((word) => {
            const rootWord = word.endsWith("s") ? word.slice(0, -1) : word
            return productText.includes(word) || productText.includes(rootWord)
          })

          const matchesCategory = cleanCategory ? productText.includes(cleanCategory) : false

          return matchesKeyword || matchesCategory
        })

        if (aiMatched.length > 0) {
          setResults(aiMatched.slice(0, 10))
        } else {
          setResults(localResults.slice(0, 10))
        }
      } catch (error) {
        console.error("AI Search Error:", error)
      } finally {
        setLoading(false)
      }
    }, 400)

    return () => clearTimeout(timer)
  }, [query, searchProducts, products])

  const onSubmit = (e) => {
    e.preventDefault()
    if (!query.trim()) return
    navigate(`/search?q=${encodeURIComponent(query.trim())}`)
    setSearchOpen(false)
  }

  return (
    <AnimatePresence>
      {searchOpen && (
        <motion.div
          className="fixed inset-0 z-[80] flex flex-col bg-nova-bg/98 backdrop-blur"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          role="dialog"
          aria-label="Search"
        >
          <div className="mx-auto flex w-full max-w-3xl flex-1 flex-col px-6 pt-24 md:pt-32">
            <button
              type="button"
              aria-label="Close search"
              onClick={() => setSearchOpen(false)}
              className="absolute right-6 top-6 grid h-11 w-11 place-items-center transition-colors hover:text-[var(--accent)] md:right-8 md:top-8"
            >
              <X size={22} />
            </button>

            <motion.form
              onSubmit={onSubmit}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              className="flex items-center gap-4 border-b border-nova-ink pb-4"
            >
              <Search size={22} className="shrink-0 text-nova-muted" />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search pieces, objects, worlds..."
                style={{ outline: "none", boxShadow: "none" }}
                className="w-full border-none bg-transparent font-display text-3xl placeholder:text-nova-muted focus:outline-none focus:ring-0 md:text-4xl"
              />
              {loading ? (
                <Loader2 size={20} className="animate-spin shrink-0 text-nova-muted" />
              ) : (
                <Sparkles size={20} className="shrink-0 text-nova-muted opacity-60" />
              )}
            </motion.form>

            {/* AI Active Filters/Badges */}
            {aiIntent && (aiIntent.maxPrice || aiIntent.category) && (
              <div className="mt-3 flex items-center gap-2">
                <span className="text-[10px] uppercase tracking-wider text-nova-muted flex items-center gap-1">
                  <Sparkles size={12} /> AI Filtered:
                </span>
                {aiIntent.maxPrice && (
                  <span className="rounded-full bg-nova-border/60 px-2.5 py-0.5 text-xs text-nova-ink">
                    Under {formatPrice(aiIntent.maxPrice)}
                  </span>
                )}
                {aiIntent.category && (
                  <span className="rounded-full bg-nova-border/60 px-2.5 py-0.5 text-xs text-nova-ink">
                    Category: {aiIntent.category}
                  </span>
                )}
              </div>
            )}

            <div className="mt-8 flex-1 overflow-y-auto pb-16">
              {!query.trim() && (
                <p className="text-xs uppercase tracking-[0.2em] text-nova-muted">
                  Type to start smart searching...
                </p>
              )}

              {query.trim() && results.length === 0 && !loading && (
                <p className="text-nova-muted">No pieces match "{query}" yet.</p>
              )}

              <ul className="flex flex-col divide-y divide-nova-border">
                {results.map((product, i) => (
                  <motion.li
                    key={product.id || product._id || i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.05 * i, duration: 0.3 }}
                  >
                    <Link
                      to={`/product/${product.id || product._id}`}
                      onClick={() => setSearchOpen(false)}
                      className="group flex items-center gap-5 py-4"
                    >
                      <div className="h-16 w-14 shrink-0 overflow-hidden bg-nova-border/40">
                        <img
                          src={product.images?.[0] || product.image}
                          alt=""
                          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                        />
                      </div>
                      <div className="flex-1">
                        <p className="font-display text-xl">{product.name || product.title}</p>
                        <p className="text-xs uppercase tracking-[0.16em] text-nova-muted">
                          {product.category}
                        </p>
                      </div>
                      <p className="text-sm text-nova-muted">{formatPrice(product.price)}</p>
                    </Link>
                  </motion.li>
                ))}
              </ul>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}