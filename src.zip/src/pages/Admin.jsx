import { useMemo, useRef, useState } from "react"
import { Link, Navigate } from "react-router-dom"
import { Check, Film, ImagePlus, Loader2 } from "lucide-react"
import { useStore } from "../context/StoreContext"
import { api } from "../lib/api"
import { formatPrice } from "../lib/format"

function CampaignVideoCard() {
  const { settings, refreshSettings } = useStore()
  const fileInputRef = useRef(null)
  const [status, setStatus] = useState("idle")
  const [error, setError] = useState("")

  const onPick = () => fileInputRef.current?.click()

  const onFileChosen = async (e) => {
    const file = e.target.files?.[0]
    e.target.value = ""
    if (!file) return

    setError("")
    setStatus("uploading")
    try {
      const uploadRes = await api.uploadFile("/media/upload", file, { folder: "site" })
      const { url, fileId } = uploadRes.data.file

      setStatus("saving")
      await api.patch("/settings", { campaignVideo: { url, fileId } })

      await refreshSettings()
      setStatus("done")
      setTimeout(() => setStatus("idle"), 1800)
    } catch (err) {
      setError(err.message || "Something went wrong")
      setStatus("error")
    }
  }

  const busy = status === "uploading" || status === "saving"
  const hasVideo = !!settings?.campaignVideo?.url

  return (
    <div className="mb-10 overflow-hidden rounded-2xl border border-nova-border bg-white">
      <button
        type="button"
        onClick={onPick}
        disabled={busy}
        className="relative block aspect-[21/9] w-full overflow-hidden bg-nova-ink"
      >
        {hasVideo ? (
          <video
            key={settings.campaignVideo.url}
            src={settings.campaignVideo.url}
            className="h-full w-full object-cover"
            muted
            loop
            autoPlay
            playsInline
          />
        ) : (
          <div className="grid h-full place-items-center text-white/50">
            <Film size={32} />
          </div>
        )}

        <div
          className={`absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/55 text-white transition-opacity ${
            busy || status === "done" || status === "error" ? "opacity-100" : "opacity-0 hover:opacity-100"
          }`}
        >
          {status === "uploading" && (
            <>
              <Loader2 size={24} className="animate-spin" />
              <span className="text-sm">Uploading…</span>
            </>
          )}
          {status === "saving" && (
            <>
              <Loader2 size={24} className="animate-spin" />
              <span className="text-sm">Saving…</span>
            </>
          )}
          {status === "done" && (
            <>
              <Check size={26} />
              <span className="text-sm">Updated</span>
            </>
          )}
          {status === "error" && <span className="max-w-[80%] text-center text-sm text-red-200">{error}</span>}
          {status === "idle" && (
            <>
              <ImagePlus size={24} />
              <span className="text-sm">{hasVideo ? "Click to replace this video" : "Click to upload a video"}</span>
            </>
          )}
        </div>
      </button>

      <input ref={fileInputRef} type="file" accept="video/*" className="hidden" onChange={onFileChosen} />

      <div className="p-4">
        <p className="text-[10px] uppercase tracking-[0.14em] text-nova-muted">Homepage</p>
        <p className="mt-0.5 text-sm font-medium text-nova-ink">"Move through the worlds" campaign film</p>
      </div>
    </div>
  )
}

function ProductPhotoCard({ product, categoryName }) {
  const { refreshCatalog } = useStore()
  const fileInputRef = useRef(null)
  const [status, setStatus] = useState("idle") // idle | uploading | saving | done | error
  const [error, setError] = useState("")

  const onPick = () => fileInputRef.current?.click()

  const onFileChosen = async (e) => {
    const file = e.target.files?.[0]
    e.target.value = "" // allow picking the same file again later
    if (!file) return

    setError("")
    setStatus("uploading")
    try {
      const uploadRes = await api.uploadFile("/media/upload", file, { folder: product.category })
      const { url, fileId } = uploadRes.data.file

      setStatus("saving")
      await api.patch(`/products/${product.id}`, {
        images: [{ url, fileId }],
      })

      await refreshCatalog()
      setStatus("done")
      setTimeout(() => setStatus("idle"), 1800)
    } catch (err) {
      setError(err.message || "Something went wrong")
      setStatus("error")
    }
  }

  const busy = status === "uploading" || status === "saving"

  return (
    <div className="group relative overflow-hidden rounded-2xl border border-nova-border bg-white">
      <button
        type="button"
        onClick={onPick}
        disabled={busy}
        className="relative block aspect-[4/5] w-full overflow-hidden bg-nova-bg"
      >
        <img
          src={product.images[0]}
          alt={product.name}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
        />

        <div
          className={`absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/55 text-white transition-opacity ${
            busy || status === "done" || status === "error" ? "opacity-100" : "opacity-0 group-hover:opacity-100"
          }`}
        >
          {status === "uploading" && (
            <>
              <Loader2 size={22} className="animate-spin" />
              <span className="text-xs">Uploading…</span>
            </>
          )}
          {status === "saving" && (
            <>
              <Loader2 size={22} className="animate-spin" />
              <span className="text-xs">Saving to product…</span>
            </>
          )}
          {status === "done" && (
            <>
              <Check size={24} />
              <span className="text-xs">Updated</span>
            </>
          )}
          {status === "error" && <span className="max-w-[80%] text-center text-xs text-red-200">{error}</span>}
          {status === "idle" && (
            <>
              <ImagePlus size={22} />
              <span className="text-xs">Click to replace photo</span>
            </>
          )}
        </div>
      </button>

      <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={onFileChosen} />

      <div className="p-3">
        <p className="text-[10px] uppercase tracking-[0.14em] text-nova-muted">{categoryName}</p>
        <p className="mt-0.5 truncate text-sm font-medium text-nova-ink">{product.name}</p>
        <p className="mt-0.5 text-xs text-nova-muted">{formatPrice(product.price)}</p>
      </div>
    </div>
  )
}

export default function Admin() {
  const { user, authLoading, products, categories, catalogLoading } = useStore()
  const [activeCategory, setActiveCategory] = useState("all")
  const [search, setSearch] = useState("")

  const filtered = useMemo(() => {
    let list = activeCategory === "all" ? products : products.filter((p) => p.category === activeCategory)
    if (search.trim()) {
      const q = search.trim().toLowerCase()
      list = list.filter((p) => p.name.toLowerCase().includes(q))
    }
    return list
  }, [products, activeCategory, search])

  if (authLoading || catalogLoading) return null

  if (!user) {
    return (
      <div className="mx-auto max-w-md px-5 py-24 text-center">
        <h1 className="font-display text-3xl">Admins only</h1>
        <p className="mt-3 text-nova-muted">Sign in with an admin account to manage product photos.</p>
        <Link to="/login" state={{ from: "/admin" }} className="mt-6 inline-block underline">
          Sign in
        </Link>
      </div>
    )
  }

  if (user.role !== "admin") {
    return <Navigate to="/" replace />
  }

  return (
    <div className="mx-auto max-w-7xl px-5 py-12 md:px-8">
      <p className="text-[11px] uppercase tracking-[0.28em] text-nova-muted">Admin</p>
      <h1 className="mt-2 font-display text-4xl">Site media</h1>
      <p className="mt-2 max-w-xl text-sm text-nova-muted">
        Click any photo or video below to replace it. It uploads straight to ImageKit and saves in
        the right place automatically — no copying URLs.
      </p>

      <div className="mt-10">
        <p className="text-[11px] uppercase tracking-[0.2em] text-nova-muted">Site-wide</p>
        <div className="mt-3">
          <CampaignVideoCard />
        </div>
      </div>

      <p className="mt-2 text-[11px] uppercase tracking-[0.2em] text-nova-muted">Products</p>

      <div className="mt-8 flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={() => setActiveCategory("all")}
          className={`rounded-full border px-4 py-2 text-xs uppercase tracking-[0.12em] transition-colors ${
            activeCategory === "all"
              ? "border-nova-ink bg-nova-ink text-white"
              : "border-nova-border text-nova-muted hover:border-nova-ink hover:text-nova-ink"
          }`}
        >
          All ({products.length})
        </button>
        {categories.map((c) => (
          <button
            key={c.slug}
            type="button"
            onClick={() => setActiveCategory(c.slug)}
            className={`rounded-full border px-4 py-2 text-xs uppercase tracking-[0.12em] transition-colors ${
              activeCategory === c.slug
                ? "border-nova-ink bg-nova-ink text-white"
                : "border-nova-border text-nova-muted hover:border-nova-ink hover:text-nova-ink"
            }`}
          >
            {c.name} ({products.filter((p) => p.category === c.slug).length})
          </button>
        ))}

        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search products…"
          className="ml-auto w-full max-w-xs border border-nova-border bg-white px-4 py-2 text-sm outline-none focus:border-nova-ink"
        />
      </div>

      <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {filtered.map((product) => {
          const category = categories.find((c) => c.slug === product.category)
          return (
            <ProductPhotoCard key={product.id} product={product} categoryName={category?.name || product.category} />
          )
        })}
      </div>

      {filtered.length === 0 && <p className="mt-16 text-center text-nova-muted">No products match that filter.</p>}
    </div>
  )
}
